##Projeto 1 de Grafos

Esse projeto possui até então 3 funcionalidades:
Imprimir os vértices e seus vizinhos;
Dar o Coeficiente de Aglomeração do Vértice;
Dar o Coeficiente de Aglomeração do grafo;

Para a construção inicial do grafo utilizou-se como referência o seguinte repositório por Marcos Castro:
https://gist.github.com/marcoscastro/76634e1d38d0d7eef2e1

Para compilar o trabalho digite no terminal

 g++ -Wall -g -o constroi constroi.cpp